# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import torch.nn.functional as F
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
from main import *
import json
from copy import deepcopy
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"




#加载标准化模型
xScaler = joblib.load("Static/xScaler.pkl")
yScaler = joblib.load("Static/yScaler.pkl")

dnn.load_state_dict(torch.load('Static/best.pth'))
print("------------------------------手动输入-----------------------------------")
data = [909,	4.14,	510,	2.81,	13.79,	38.18,	14.65,	21.62,	8.96]
data2 = deepcopy(data)
data = np.array(data).reshape(1,-1)
data = xScaler.transform(data).reshape(-1,len(inCols)).tolist()
dnn.eval()
x = torch.FloatTensor(data).reshape(1,-1)
yPred = dnn(x).detach().numpy().reshape(-1,len(outCols))
yPred = yScaler.inverse_transform(yPred)#数据归一化还原
yPred = np.round(yPred.tolist()[0],3)#保留3位小数
print("手动输入:")
print(data2)
print("输出:")
print(yPred)
print("-----------------------------------------------------------------------")

