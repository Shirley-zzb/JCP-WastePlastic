# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 18:03:59 2022

@author: zhouxin
"""
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.optimize import minimize
from Main1 import problem
import matplotlib.pyplot as plt
import time
import numpy as np
from pymoo.visualization.scatter import Scatter


##############################################################求解方法1
# start = time.time()
# algorithm = NSGA2(
#     pop_size=100,
#     n_offsprings=5,
#     eliminate_duplicates=True
# )

# res = minimize(problem,
#                 algorithm,
#                 ('n_gen', 20),
#                 seed=1,
#                 verbose=True
#                 )
# end = time.time()
# # plt.scatter(res.F[:, 0], res.F[:, 1], marker="o", s=10)
# # plt.grid(True)
# # plt.show()
# print('耗时：', end - start, '秒')


# ##############################################################求解方法2
# algorithm = NSGA2(pop_size=40, elimate_duplicates=False)
# start = time.time()
# res = minimize(problem,
#                 algorithm,
#                 ('n_gen', 300),
#                 verbose=False)
# end = time.time()
# plt.scatter(res.F[:, 0], res.F[:, 1], marker="o", s=10)
# plt.grid(True)
# plt.show()
# print('耗时：', end - start, '秒')

#############################################################求解方法3
#create the reference directions to be used for the optimization

# ref_dirs = get_reference_directions("das-dennis", 5, n_partitions=100)
# algorithm = NSGA3(pop_size=100000000,
#                   ref_dirs=ref_dirs)

# # execute the optimization
# res = minimize(problem,
#                 algorithm,
#                 seed=1,
#                 termination=('n_gen', 600))
# plt.scatter(res.F[:, 0], res.F[:, 1], marker="o", s=10)
# plt.grid(True)
# plt.show()


#############################################################求解方法4
from pymoo.algorithms.moo.rvea import RVEA

ref_dirs = get_reference_directions("das-dennis", 5, n_partitions=5)

algorithm = RVEA(ref_dirs)

res = minimize(problem,
               algorithm,
               termination=('n_gen', 10),
               seed=1,
               verbose=False)
#可调整，后一个参数需要跟维度一致
F = np.random.random((30, 5))

plot = Scatter(tight_layout=True)
plot.add(F, s=10)
plot.add(F[10], s=30, color="red")
plot.show()


##############################################################
print(res.F)
print(res.X)