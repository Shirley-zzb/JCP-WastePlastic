

import numpy as np
from pymoo.core.problem import ElementwiseProblem
import pandas as pd
import matplotlib.pyplot as plt
import time
from numpy import *


import pandas as pd
import numpy as np
import torch.nn.functional as F
import torch.nn as nn
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
from main import *
import json
from copy import deepcopy
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
#starting time  


class MyProblem(ElementwiseProblem):

  
 

    def __init__(self):
        super().__init__(n_var=6,
                          n_obj=5,
                          n_constr=0,
                          xl=np.array([160,200,650,670,18,25]),
                          xu=np.array([190,230,670,700,25,30]))

    def _evaluate(self, x, out, *args, **kwargs):

   
     
        
        #加载标准化模型
        xScaler = joblib.load("Static/xScaler.pkl")
        yScaler = joblib.load("Static/yScaler.pkl")
        dnn.load_state_dict(torch.load('Static/best.pth'))
        #print("------------------------------手动输入-----------------------------------")
        data = [x[0],	x[1],	x[2],	x[3],	x[4],	x[5]]
        data2 = deepcopy(data)
        data = np.array(data).reshape(1,-1)
        data = xScaler.transform(data).reshape(-1,len(inCols)).tolist()
        dnn.eval()
        x = torch.FloatTensor(data).reshape(1,-1)
        yPred = dnn(x).detach().numpy().reshape(-1,len(outCols))
        yPred = yScaler.inverse_transform(yPred)#数据归一化还原
        yPred = np.round(yPred.tolist()[0],3)#保留3位小数
        #print("手动输入:")
        #print(data2)
        #print("输出:")
        #print(yPred)
        #print("-----------------------------------------------------------------------")
        
         # Set the CellValue, y to f1
        f1 = -yPred[0] 
        f2 = yPred[1] 
        f3 = yPred[2] 
        f4 = -yPred[3] 
        f5 = yPred[4] 

        
        
        

        out["F"] = [f1, f2, f3, f4, f5]



problem = MyProblem()
     